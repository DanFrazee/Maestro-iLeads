//
//  PhoneNumber.m
//  Maestro iLeads
//
//  Created by Dan Frazee on 9/13/12.
//  Copyright (c) 2012 Maestro. All rights reserved.
//

#import "PhoneNumber.h"
#import "Person.h"
#import "PhoneTypes.h"


@implementation PhoneNumber

@dynamic number;
@dynamic person;
@dynamic type;

@end

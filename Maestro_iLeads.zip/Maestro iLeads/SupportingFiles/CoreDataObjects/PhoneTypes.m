//
//  PhoneTypes.m
//  Maestro iLeads
//
//  Created by Dan Frazee on 9/13/12.
//  Copyright (c) 2012 Maestro. All rights reserved.
//

#import "PhoneTypes.h"
#import "PhoneNumber.h"


@implementation PhoneTypes

@dynamic name;
@dynamic number;

@end

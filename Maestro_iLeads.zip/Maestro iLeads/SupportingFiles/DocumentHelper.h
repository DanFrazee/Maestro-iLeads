//
//  DocumentHelper.h
//  Maestro Sales Leads
//
//  Created by Dan Frazee on 9/13/12.
//  Copyright (c) 2012 Maestro Mobile. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DocumentHelper : NSObject


+(NSString*)setDocumentPathForImage:(UIImage*)image;

@end
